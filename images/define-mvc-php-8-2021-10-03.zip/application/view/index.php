<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<title>Define MVC Index Controller with Index View</title>
<body>
<?= $mesg ?? "500";?>
</body>
</html>