<!DOCTYPE html>
<html lang="en">
<title>HTTP Error <?= $title ?? "500" ?></title>
<body>
<?= $errorMsg ?? "500" ?>
</body>
</html>