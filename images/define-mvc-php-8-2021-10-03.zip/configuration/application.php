<?php
declare(strict_types=1);

if(DIRECT_ACCESS != true) die("Direct access is forbidden");